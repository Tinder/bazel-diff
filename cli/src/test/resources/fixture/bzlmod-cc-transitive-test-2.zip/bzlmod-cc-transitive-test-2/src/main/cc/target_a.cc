#include "src/main/cc/target_a.h"

namespace test {

std::string TargetA::GetFullMessage() {
  return "TargetA says: " + target_b_.GetMessage();
}

}  // namespace test
