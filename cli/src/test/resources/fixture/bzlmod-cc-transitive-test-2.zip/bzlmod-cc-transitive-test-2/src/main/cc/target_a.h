#ifndef TARGET_A_H
#define TARGET_A_H

#include <string>
#include "src/main/cc/target_b.h"

namespace test {

class TargetA {
 public:
  std::string GetFullMessage();

 private:
  TargetB target_b_;
};

}  // namespace test

#endif  // TARGET_A_H
