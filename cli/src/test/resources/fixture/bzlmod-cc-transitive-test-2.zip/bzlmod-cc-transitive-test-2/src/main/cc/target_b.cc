#include "src/main/cc/target_b.h"
#include "absl/strings/str_cat.h"

namespace test {

std::string TargetB::GetMessage() {
  return absl::StrCat("Hello", " ", "from", " ", "TargetB");
}

}  // namespace test
