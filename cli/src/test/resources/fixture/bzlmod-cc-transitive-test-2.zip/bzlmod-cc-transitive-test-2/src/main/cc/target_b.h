#ifndef TARGET_B_H
#define TARGET_B_H

#include <string>

namespace test {

class TargetB {
 public:
  std::string GetMessage();
};

}  // namespace test

#endif  // TARGET_B_H
