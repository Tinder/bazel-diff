package com.transitive;

import com.google.common.collect.ImmutableList;

public class TargetB {
    public ImmutableList<String> getItems() {
        return ImmutableList.of("item1", "item2");
    }
}
