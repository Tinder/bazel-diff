package com.transitive;

public class TargetA {
    private final TargetB targetB = new TargetB();

    public void printItems() {
        System.out.println(targetB.getItems());
    }
}
