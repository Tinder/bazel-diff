package cli.src.test.resources.integration.src.main.java.com.integration;

import com.google.common.collect.ImmutableList;

public class GuavaUserAndroid {
  // add a comment
}
