package cli.src.test.resources.integration.src.main.java.com.integration.submodule;

public class Submodule {

}
